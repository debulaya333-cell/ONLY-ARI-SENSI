package com.onlyari.sensi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

public class FloatingOverlayService extends Service {
    private WindowManager wm;
    private TextView bubble;
    private WindowManager.LayoutParams params;
    private static final String CHANNEL = "only_ari_overlay";

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        showBubble();
    }

    private void createNotification() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "ONLY ARI Floating Shortcut",
                    NotificationManager.IMPORTANCE_LOW));
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification n = b.setContentTitle("ONLY ARI SENSI")
                .setContentText("Floating shortcut is active. Tap it to open your settings.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi).setOngoing(true).build();
        startForeground(41, n);
    }

    private void showBubble() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setText("♛\nONLY ARI");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(11);
        bubble.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(23,40,58), Color.rgb(5,15,27)});
        bg.setCornerRadius(dp(17));
        bg.setStroke(dp(2), Color.rgb(255,65,91));
        bubble.setBackground(bg);
        bubble.setElevation(dp(12));

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(68), dp(68), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(12);
        params.y = dp(180);

        bubble.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{e.getRawX(), e.getRawY(), params.x, params.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] p = (float[])v.getTag();
                    params.x = (int)(p[2] + e.getRawX() - p[0]);
                    params.y = (int)(p[3] + e.getRawY() - p[1]);
                    try { wm.updateViewLayout(bubble, params); } catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    float[] q = (float[])v.getTag();
                    float dx = e.getRawX() - q[0], dy = e.getRawY() - q[1];
                    if (Math.abs(dx) < dp(8) && Math.abs(dy) < dp(8)) {
                        Intent launch = new Intent(this, MainActivity.class);
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(launch);
                    }
                    return true;
            }
            return false;
        });
        try { wm.addView(bubble, params); } catch (Exception ignored) {}
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (wm != null && bubble != null) try { wm.removeView(bubble); } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
